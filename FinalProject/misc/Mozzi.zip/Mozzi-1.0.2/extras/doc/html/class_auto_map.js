var class_auto_map =
[
    [ "AutoMap", "class_auto_map.html#aec125f071bd83180ff0d0a71446725f3", null ],
    [ "getMax", "class_auto_map.html#a4d27e5fe43f9b376b537def88ac74119", null ],
    [ "getMin", "class_auto_map.html#acd1dae6e6ffb288efc1618e2453ad5ef", null ],
    [ "getRange", "class_auto_map.html#a75c842b27ad3917be6d29e3d35b485f3", null ],
    [ "next", "class_auto_map.html#a34bc821f4f662e54383dd9d61db782df", null ],
    [ "operator()", "class_auto_map.html#afd49885d3f05ca0a2f417199a9e7cf10", null ]
];